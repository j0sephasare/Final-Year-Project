import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imageupload',
  templateUrl: './imageupload.page.html',
  styleUrls: ['./imageupload.page.scss'],
})
export class ImageuploadPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
