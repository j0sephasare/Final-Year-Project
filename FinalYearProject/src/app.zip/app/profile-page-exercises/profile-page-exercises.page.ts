import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-page-exercises',
  templateUrl: './profile-page-exercises.page.html',
  styleUrls: ['./profile-page-exercises.page.scss'],
})
export class ProfilePageExercisesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
